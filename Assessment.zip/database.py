import sqlite3

conn = sqlite3.connect("database.db")

c= conn.cursor()

# c.execute(''' CREATE TABLE match (

# 			player text,
# 			scored integer,
# 			faced integer,
# 			fours integer,
# 			sixes integer,
# 			bowled integer,
# 			maiden integer,
# 			given integer,
# 			wkts integer,
# 			catches integer,
# 			stumping integer,
# 			ro integer)''')

# c.execute(''' CREATE TABLE teams (
# 				name text,
# 				players text,
# 				value integer)''')

# c.execute(''' CREATE TABLE stats (
# 				player text,
# 				matches integer,
# 				runs integer,
# 				"100s" integer,
# 				"50s" integer,
# 				value integer,
# 				ctg text)''')

# c.execute("CREATE TABLE match_detail (match_name text, date_time text, place text)")

# c.execute("INSERT INTO match_detail VALUES('match','19-10-2021','bankheda')")
# data=[['Kohli'       ,102,98,8,2,0 ,0,0 ,0,0,0,1,120,189,8257,28,43,"BAT"],
# 	  ['Yuvraj'      ,12 ,20,1,0,48,0,36,1,0,0,0,100,86 ,3589,10,21,"BAT"],
# 	  ['Rahane'      ,49 ,75,3,0,0 ,0,0 ,0,1,0,0,100,158,5435,11,31,"BAT"],
# 	  ['Dhawan'      ,32 ,35,4,0,0 ,0,0 ,0,0,0,0,85 ,25 ,565 ,2 ,1 ,"AR"],
# 	  ['Dhoni'       ,56 ,45,3,1,0 ,0,0 ,0,3,2,0,75 ,78 ,2573,3 ,19,"BAT"],
# 	  ['Axar'        ,8  ,4 ,2,0,48,2,35,1,0,0,0,100,67 ,208 ,0 ,0 ,"BWL"],
# 	  ['Pandya'      ,42 ,36,3,3,30,0,25,0,1,0,0,75 ,70 ,77  ,0 ,0 ,"BWL"],
# 	  ['Jadeja'      ,18 ,10,1,1,60,3,50,2,1,0,1,85 ,16 ,1   ,0 ,0 ,"BWL"],
# 	  ['Kedar'       ,65 ,60,7,0,24,0,24,0,0,0,0,90 ,111,675 ,0 ,1 ,"BWL"],
# 	  ['Ashwin'      ,23 ,42,3,0,60,2,45,6,0,0,0,100,136,1914,0 ,10,"AR"],
# 	  ['Umesh'       ,0  ,0 ,0,0,54,0,50,4,1,0,0,110,296,9496,10,64,"WK"],
# 	  ['Bumrah'      ,0  ,0 ,0,0,60,2,49,1,0,0,0,60 ,73 ,1365,0 ,8 ,"WK"],
# 	  ['Bhuwaneshwar',15 ,12,2,0,60,1,46,2,0,0,0,75 ,17 ,289 ,0 ,2 ,"AR"],
# 	  ['Rohit'       ,46 ,65,5,1,0 ,0,0 ,0,1,0,0,85 ,304,8701,14,52,"BAT"],
# 	  ['Kartick'     ,29 ,42,3,0,0 ,0,0 ,0,2,0,1,75 ,11 ,111 ,0 ,0 ,"AR"]]


# match_query="INSERT INTO match VALUES(?,?,?,?,?,?,?,?,?,?,?,?)"
# stats_query="INSERT INTO stats VALUES(?,?,?,?,?,?,?)"
# for i in data:
# 	data_tuple1=i[:12]
# 	c.execute(match_query,data_tuple1)
# 	data_tuple2=(i[0],i[13],i[14],i[15],i[16],i[12],i[17])
# 	c.execute(stats_query,data_tuple2)


conn.commit()

conn.close()

