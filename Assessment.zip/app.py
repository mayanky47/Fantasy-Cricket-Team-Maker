from PyQt5.QtWidgets import *
from PyQt5 import uic,QtCore
import sys


#database
import sqlite3
conn = sqlite3.connect("database.db")
c= conn.cursor()

#queries..............

query_for_count="SELECT COUNT(*) FROM stats WHERE ctg=:cat"

query_for__player="SELECT player FROM stats WHERE ctg=:cat"

query_for_value="SELECT value,ctg FROM stats WHERE player=:player"

team_query="INSERT INTO teams VALUES (?,?,?)"

query_for_team_player ='SELECT players FROM teams WHERE name=:name'

query_for_match_point ="SELECT value FROM teams WHERE mat=:match_name"

query_for_team_list ='SELECT name FROM teams'

query_for_open_team ='SELECT players,value FROM teams WHERE name=:name'

query_for_update_team="UPDATE teams SET players=?,value=? WHERE name=?"


#UI classs
class UI(QMainWindow):
	def __init__(self):
		super(UI, self).__init__()


		#Load the ui file

		uic.loadUi("ui_design.ui",self)

		self.setWindowTitle("Fantasy Cricket Team maker")
		#Define Our Widgets
		self.Bat_count =self.findChild(QLabel,"Batsmen")
		self.Bwl_count =self.findChild(QLabel,"Bowlers")
		self.Ar_count = self.findChild(QLabel,"AR")
		self.Wk_count =self.findChild(QLabel,"WK")

		self.Player_list =self.findChild(QListWidget,"player_list")

		self.new_team=self.findChild(QAction,"new_team")
		self.open_team=self.findChild(QAction,"open_team")
		self.evaluate_team=self.findChild(QAction,"evaluate_team")

		self.av_pt =self.findChild(QLabel,"Av_pt")
		self.used_pt=self.findChild(QLabel,"used_pt")
		self.Team_name=self.findChild(QLabel,"Team_name")
		self.team_list=self.findChild(QListWidget,"team_list")
		


		#Set values 
		c.execute(query_for_count,{"cat":"BAT"})
		count_batsmen= c.fetchall()[0][0]
		self.Bat_count.setNum(count_batsmen)

		c.execute(query_for_count,{"cat":"BWL"})
		count_bwl= c.fetchall()[0][0]
		self.Bwl_count.setText(str(count_bwl))

		c.execute(query_for_count,{"cat":"AR"})
		count_ar=c.fetchall()[0][0]
		self.Ar_count.setText(str(count_ar))

		c.execute(query_for_count,{"cat":"WK"})
		count_wk=c.fetchall()[0][0]
		self.Wk_count.setText(str(count_wk))

		#Events

		self.Bat_button.toggled.connect(self.checker)
		self.Bwl_button.toggled.connect(self.checker)
		self.AR_button.toggled.connect(self.checker)
		self.WK_button.toggled.connect(self.checker)

		self.new_team.triggered.connect(self.create_team)

		self.open_team.triggered.connect(self.open_saved_team)

		self.save_team.triggered.connect(self.store_team)

		self.Player_list.itemDoubleClicked.connect(self.itemselect)
		self.team_list.itemDoubleClicked.connect(self.itemdeselect)

		self.evaluate_team.triggered.connect(self.evaluate)

		self.show()

	def checker(self):
		data=""
		if self.Bat_button.isChecked():
			data="BAT"
		elif self.Bwl_button.isChecked():
			data="BWL"
		elif self.AR_button.isChecked():
			data="AR"
		elif self.WK_button.isChecked():
			data="WK"
		if data is not None:
			self.Player_list.clear()
			c.execute(query_for__player,{"cat":data})
			data_list =[]
			for i in c.fetchall():
				data_list.append(i[0])
	
			for i in data_list:
				flag=False

				for x in range(self.team_list.count()):
					if i==self.team_list.item(x).data(0):
						flag=True
				if flag ==False:
					self.Player_list.addItem(QListWidgetItem(i))
				flag=False

	def create_team(self):
		text,result=QInputDialog.getText(self, "Input Dialog","Enter Your Team name:")
		if result==True and len(text)!=0:

			c.execute(query_for_team_list)
			team_list =[]
			for i in c.fetchall():
				team_list.append(i[0])
			if text in team_list:
				msg=QMessageBox()
				msg.setWindowTitle("Error")
				msg.setIcon(QMessageBox.Critical)
				msg.setText("Team of This Name Already exist")
				msg.exec_()

			else:
				self.team_list.clear()
				self.Team_name.setText(text)
				self.av_pt.setNum(1000)
				self.used_pt.setNum(0)
				self.Bat_button.setChecked(True)
				self.checker()

	def itemselect(self):
		try:
			if self.team_list.count() !=10:
				item=self.Player_list.currentItem()
				data=item.data(0)
				c.execute(query_for_value,{"player":data})
				data_tuple=c.fetchall()[0]
				value=data_tuple[0]
				ctg=data_tuple[1]
				flag=False
				if ctg=="WK":				
					c.execute(query_for__player,{"cat":ctg})
					wk_list =[]
					for i in c.fetchall():
						wk_list.append(i[0])
					for x in range(self.team_list.count()):
						if self.team_list.item(x).data(0) in wk_list:
								flag=True
								msg=QMessageBox()
								msg.setWindowTitle("Error")
								msg.setIcon(QMessageBox.Critical)
								msg.setText("You Can't Select More than One wicket-keeper")
								msg.exec_()
				if flag ==False:
					av_pt=int(self.av_pt.text())
					used_pt=int(self.used_pt.text())
					if av_pt >=value:
	
						av_pt -=value
						used_pt +=value
						self.av_pt.setNum(av_pt)
						self.used_pt.setNum(used_pt)
						self.Player_list.takeItem(self.Player_list.currentRow())
						self.team_list.addItem(QListWidgetItem(data))
					else:
						msg=QMessageBox()
						msg.setWindowTitle("Error")
						msg.setIcon(QMessageBox.Warning)
						msg.setText("You don't have enough points.")
						msg.exec_()
			else:
				msg=QMessageBox()
				msg.setWindowTitle("Error")
				msg.setIcon(QMessageBox.Warning)
				msg.setText("You can't select more than 10 player.")
				msg.exec_()
		except:
			msg=QMessageBox()
			msg.setWindowTitle("Error")
			msg.setIcon(QMessageBox.Warning)
			msg.setText("Create a Team First.")
			msg.exec_()

	def itemdeselect(self):
		item=self.team_list.currentItem()
		data=item.data(0)
		c.execute(query_for_value,{"player":data})
		value=c.fetchall()[0][0]
		av_pt=int(self.av_pt.text())
		used_pt=int(self.used_pt.text())
		self.team_list.takeItem(self.team_list.currentRow())
		self.checker()
		av_pt +=value
		used_pt -=value
		self.av_pt.setNum(av_pt)
		self.used_pt.setNum(used_pt)

	def store_team(self):
		if self.team_list.count()==10:
			flag=False
			c.execute(query_for__player,{"cat":"WK"})
			wk_list =[]
			for i in c.fetchall():
				wk_list.append(i[0])
			for x in range(self.team_list.count()):
				if self.team_list.item(x).data(0) in wk_list:
						flag=True
			if flag:
				temp_team_name=self.Team_name.text()
				c.execute(query_for_team_list)
				team_list =[]
				for i in c.fetchall():
					team_list.append(i[0])

				temp_player=[]
				for i in range(self.team_list.count()):
					temp_player.append(self.team_list.item(i).data(0))
				str_temp_player=",".join(temp_player)
				temp_value=int(self.used_pt.text())
				if temp_team_name in team_list:
					c.execute(query_for_update_team,(str_temp_player,temp_value,temp_team_name))	
				else:	
					c.execute(team_query,(temp_team_name,str_temp_player,temp_value))
				conn.commit()
				msg=QMessageBox()
				msg.setWindowTitle("Save")
				msg.setIcon(QMessageBox.Information)
				msg.setText("Your Team is Saved!")
				msg.exec_()
			else:
				msg=QMessageBox()
				msg.setWindowTitle("Error")
				msg.setIcon(QMessageBox.Critical)
				msg.setText("You Didn't choose wicket-keeper for your team")
				msg.exec_()

		else:
			msg=QMessageBox()
			msg.setWindowTitle("Save")
			msg.setIcon(QMessageBox.Information)
			msg.setText("Select 10 Players first !")
			msg.exec_()

	def open_saved_team(self):
		c.execute(query_for_team_list)
		teams=c.fetchall()
		team_list=[]

		for i in teams:
			team_list.append(i[0])
		team_name=""
		
		pop=Popup(team_list, self)
		if pop.exec_():
			team_name=pop.data
		if len(team_name)!=0:
			c.execute(query_for_open_team,{"name":team_name})
			details=c.fetchall()
			players=details[0][0].split(",")
			points=details[0][1]

			self.av_pt.setNum(1000-points)
			self.used_pt.setNum(points)
			self.team_list.clear()
			for i in players:
				self.team_list.addItem(QListWidgetItem(i))
			self.Team_name.setText(team_name)
			self.checker()
			self.Bat_button.setChecked(True)


	def evaluate(self):
		evaluate_win=evaluate()
		evaluate_win.Call()
		evaluate_win.exec_()
	

class evaluate(QDialog):
	def __init__(self):
		super(evaluate, self).__init__()

		#Load the ui file

		uic.loadUi("evaluate.ui",self)

		self.setWindowTitle("Performance")
		self.setWindowModality(QtCore.Qt.ApplicationModal)

		self.eval_team_select=self.findChild(QComboBox,"eval_team_select")
		self.eval_match_select=self.findChild(QComboBox,"eval_match_select")
		self.eval_players=self.findChild(QListWidget,"eval_players")
		self.eval_points=self.findChild(QListWidget,"eval_points")
		self.total_val=self.findChild(QLabel,"total_value")


		#events......

		self.eval_team_select.currentIndexChanged.connect(self.team_button_pressed)
		self.eval_match_select.currentIndexChanged.connect(self.match_button_pressed)
	def point(self,player,match):
		query_for_team_value =f'SELECT scored,faced,fours,sixes,bowled, wkts,given, catches,stumping,ro FROM {match} WHERE player="{player}"'
		value=0
		half_century=False
		century=False
		c.execute(query_for_team_value)
		temp_tuple=c.fetchall()[0]
		scored=temp_tuple[0]
		faced=temp_tuple[1]
		fours=temp_tuple[2]
		sixes=temp_tuple[3]
		if scored >=50:
			half_cenctury=True
			if scored >=100:
				century=True
		strike_rate=0
		if faced !=0:
			strike_rate=scored/faced
		value+=int(scored/2)
		value+=fours
		value+=2*sixes
		if half_century==True:
			value+=5
			if century==True:
				value+=10
		if strike_rate >=80:
			value+=2
			if strike_rate>100:
				value+=4

		#bowler.................... 
		over=0
		if temp_tuple[4] !=0:
			over =temp_tuple[4]/6
			given=temp_tuple[6]
			economy=given/over
			if economy < 4.5:
				if economy <3.5 and economy>2:
					value +=7
				elif economy < 2:
					value +=10
				else:
					value +=4
			wkt=temp_tuple[5]
			value +=10*wkt
			if wkt >=3:
				value+=5
				if wkt >=5:

					value +=10
		#fielding...................
		value+=temp_tuple[7]*10
		value+=temp_tuple[8]*10
		value+=temp_tuple[9]*10

		return value


	def Call(self):
		c.execute("SELECT * FROM teams")
		result=c.fetchall()
		for i in result:
			self.eval_team_select.addItem(i[0])
		c.execute("SELECT match_name FROM match_detail")
		result=c.fetchall()
		for i in result:
			self.eval_match_select.addItem(i[0])

	def team_button_pressed(self):
		self.eval_players.clear()
		team_name= self.eval_team_select.currentText()
		if team_name != None:
			c.execute(query_for_team_player,{"name":team_name})
			players=c.fetchall()[0][0]
			player_list=players.split(",")
			for i in player_list:
				self.eval_players.addItem(QListWidgetItem(i))

	def match_button_pressed(self):
		self.eval_points.clear()
		match_name=self.eval_match_select.currentText()
		total=0
		for x in range(self.eval_players.count()):
			i=self.eval_players.item(x).data(0)
			value=self.point(i,match_name)
			self.eval_points.addItem(QListWidgetItem(str(value)))
			total+=value

		self.total_value.setNum(total)


	def team_button_pressed(self):
		self.eval_players.clear()
		team_name= self.eval_team_select.currentText()
		if team_name != None:
			c.execute(query_for_team_player,{"name":team_name})
			players=c.fetchall()[0][0]
			player_list=players.split(",")
			for i in player_list:
				self.eval_players.addItem(QListWidgetItem(i))
		self.match_button_pressed()

	def match_button_pressed(self):
		self.eval_points.clear()
		match_name=self.eval_match_select.currentText()
		total=0
		if len(match_name) !=0:
			for x in range(self.eval_players.count()):
				i=self.eval_players.item(x).data(0)
				value=self.point(i,match_name)
				self.eval_points.addItem(QListWidgetItem(str(value)))
				total+=value
		self.total_value.setNum(total)
		self.show()

class Popup(QDialog):
	def __init__(self,teams,parent):
		super().__init__(parent)

		self.setWindowTitle("select team name")
		self.teams=teams
		self.data=None

		self.setWindowModality(QtCore.Qt.ApplicationModal)
		self.list=QListWidget(self)
		self.list.setFixedWidth(300)
		self.list.setFixedHeight(300)

		#event...
		for i in teams:
			self.list.addItem(QListWidgetItem(i))
		self.list.itemClicked.connect(self.teamOpener)
		parent.installEventFilter(self)
		self.loop = QtCore.QEventLoop(self)

	def check_input(self):
		self.loop.exit(True)

	def teamOpener(self):
		item=self.list.currentItem()
		self.data=item.data(0)
		self.check_input()
		return 

	def exec_(self):
		self.show()
		self.raise_()
		res = self.loop.exec_()
		self.hide()
		return res

app = QApplication(sys.argv)

UIWindow =UI()

app.exec_()

conn.close()